import './App.css';
import Dashboard1 from './pages/dashboard1';

function App() {
  return (
    <>
      <Dashboard1 />
    </>
  );
}

export default App;
